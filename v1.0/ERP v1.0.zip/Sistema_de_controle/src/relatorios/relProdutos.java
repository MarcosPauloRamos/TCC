/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package relatorios;

import br.com.sistema.jdbc.ConexaoBancoRelatorios;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;
import java.util.HashMap;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

public class relProdutos {

    ConexaoBancoRelatorios conexao = new ConexaoBancoRelatorios();

    public relProdutos(Frame parent) {
        try {
            conexao.conecta();
            conexao.executeSQL(
                "select p.id,p.descricao,p.preco,p.qtd_estoque,f.nome " + 
                "from tb_produtos as p inner join tb_fornecedores"
                        + " as f on(p.for_id = f.id)"
            );

            JRResultSetDataSource jrRS = new JRResultSetDataSource(conexao.resultset);

            String caminhoRelatorio = "C:\\Users\\samsung\\Documents\\NetBeansProjects\\Sistema_de_controle\\src\\relatorios\\relProdutos.jasper";
            JasperPrint jasperprint = JasperFillManager.fillReport(caminhoRelatorio, new HashMap<>(), jrRS);

            // Aqui usamos o JRViewer diretamente dentro de um JDialog
            JRViewer viewer = new JRViewer(jasperprint);

            JDialog dialog = new JDialog(parent, "Relatório de Produtos", true); // modal = true
            dialog.getContentPane().add(viewer);

            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            dialog.setSize(screenSize);
            dialog.setLocationRelativeTo(null);
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);

        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar o relatório: " + erro.getMessage());
        }
    }
}

    

