/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package relatorios;

import br.com.sistema.jdbc.ConexaoBancoRelatorios;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;
import java.util.HashMap;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

public class relFuncionarios {

    ConexaoBancoRelatorios conexao = new ConexaoBancoRelatorios();

    public relFuncionarios(Frame parent) {
        try {
            conexao.conecta();
            conexao.executeSQL(
                "SELECT id, nome, " +
                "CONCAT(endereco, \", \", numero, \", \", bairro, \", \", cidade, \", \", estado) AS endereco " +
                "FROM tb_funcionarios"
            );

            JRResultSetDataSource jrRS = new JRResultSetDataSource(conexao.resultset);

            String caminhoRelatorio = "C:\\Users\\samsung\\Documents\\NetBeansProjects\\Sistema_de_controle\\src\\relatorios\\relFuncionarios.jasper";
            JasperPrint jasperprint = JasperFillManager.fillReport(caminhoRelatorio, new HashMap<>(), jrRS);

            // Aqui usamos o JRViewer diretamente dentro de um JDialog
            JRViewer viewer = new JRViewer(jasperprint);

            JDialog dialog = new JDialog(parent, "Relatório de Funcionários", true); // modal = true
            dialog.getContentPane().add(viewer);

            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            dialog.setSize(screenSize);
            dialog.setLocationRelativeTo(null);
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);

        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar o relatório: " + erro.getMessage());
        }
    }
}

    

