/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package relatorios;

import br.com.sistema.jdbc.ConexaoBancoRelatorios;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;
import java.util.HashMap;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

public class relVendas {

    ConexaoBancoRelatorios conexao = new ConexaoBancoRelatorios();

    public relVendas(Frame parent) {
        try {
            conexao.conecta();
            conexao.executeSQL(
                "SELECT \n" +
                "    v.id AS venda_id,\n" +
                "    p.descricao AS produto,\n" +
                "    p.preco AS preco_unitario,\n" +
                "    iv.qtd AS quantidade,\n" +
                "    iv.subtotal,\n" +
                "    v.total_venda\n" +
                "FROM tb_vendas v\n" +
                "JOIN tb_itensvendas iv ON v.id = iv.venda_id\n" +
                "JOIN tb_produtos p ON iv.produto_id = p.id\n" +
                "WHERE v.id = (SELECT MAX(id) FROM tb_vendas);"
            );

            JRResultSetDataSource jrRS = new JRResultSetDataSource(conexao.resultset);

            String caminhoRelatorio = "C:\\Users\\samsung\\Documents\\NetBeansProjects\\Sistema_de_controle\\src\\relatorios\\relVendas.jasper";
            JasperPrint jasperprint = JasperFillManager.fillReport(caminhoRelatorio, new HashMap<>(), jrRS);

            // Aqui usamos o JRViewer diretamente dentro de um JDialog
            JRViewer viewer = new JRViewer(jasperprint);

            JDialog dialog = new JDialog(parent, "Relatório de Produtos", true); // modal = true
            dialog.getContentPane().add(viewer);

            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            dialog.setSize(screenSize);
            dialog.setLocationRelativeTo(null);
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);

        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "Erro ao gerar o relatório: " + erro.getMessage());
        }
    }
}

    

